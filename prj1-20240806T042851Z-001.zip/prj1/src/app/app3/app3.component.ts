import { Component } from '@angular/core';

@Component({
  selector: 'app-app3',
  standalone: true,
  imports: [],
  templateUrl: './app3.component.html',
  styleUrl: './app3.component.css'
})
export class App3Component {

}
